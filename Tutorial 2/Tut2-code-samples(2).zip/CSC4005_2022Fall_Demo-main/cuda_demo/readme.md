# CUDA demo

Contact: bokaixu@link.cuhk.edu.cn

## Compile

```bash
nvcc -o cuda_hello cuda_hello.cpp
```

## Run

```bash
./cuda_hello
```

Output should be like

```
4291104 CUDA devices detected
```