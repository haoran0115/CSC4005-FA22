# OpenMP demo

Contact: bokaixu@link.cuhk.edu.cn

## Compile

```bash
g++ -o openmp_hello openmp_hello.cpp -fopenmp
```

## Run

```bash
./openmp_hello
```

Output should be like

```
Hello, world!
Hello, world!
Hello, world!
Hello, world!
Hello, world!
```