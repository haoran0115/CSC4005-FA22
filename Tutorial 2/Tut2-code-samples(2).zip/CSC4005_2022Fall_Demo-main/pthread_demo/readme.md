# Pthreads demo

Contact: bokaixu@link.cuhk.edu.cn

## Compile

```bash
g++ -o pthread_hello pthread_hello.cpp -lpthread
```

## Run

```bash
./pthread_hello
```

Output should be like

```
Created Thread 140185512527616
Id: 140185512527616
Welcome to Pthreads Programming
Thread 140185512527616 terminated, Status = 0
```
